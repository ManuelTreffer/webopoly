<?php

$min = 1;
$max = 6;

$wuerfelzahl = rand($min, $max);

echo $wuerfelzahl;

