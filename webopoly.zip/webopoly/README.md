# webopoly
Webopoly, the world's leading drinking game made by the WEB students in Kufstein!

# What is Webopoly?
Webopoly is a fun game you either can play alone (why not?) or together in a group of max. 8 people.

#So, what are the rules?
The rules are very simple.

1. You have to "roll the dice".
2. Your emoji will automatically move forward.
3. Depending on the field you are now at, you either have to:
  -Drink something
  -Do something
  -Answer a question
  -SURPRISE

You decide if you get the point or not. So, please be honest to yourself.

Winner is the person with the highest score.
