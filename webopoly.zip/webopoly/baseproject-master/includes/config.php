<?php

define('URL_PATH', '/webopoly/baseproject-master');

define('LOGIN_URL', 'login');
define('LOGOUT_URL', 'logout');
define('INDEX_URL', 'index');

