<?php

define('URL_PATH', '/kufstein/baseproject');

define('LOGIN_URL', 'login');
define('LOGOUT_URL', 'logout');
define('INDEX_URL', 'index');

