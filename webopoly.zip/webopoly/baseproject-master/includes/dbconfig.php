<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'testdatenbank_webopoly');
define('DB_USER', 'webopolyteam');
define('DB_PASS', 'webopoly');
