<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'testdatabase');
define('DB_USER', 'testuser');
define('DB_PASS', 'testpass');
