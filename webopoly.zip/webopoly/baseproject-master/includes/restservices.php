<?php

$restfulservices[] = array('Address', 'processRequest');