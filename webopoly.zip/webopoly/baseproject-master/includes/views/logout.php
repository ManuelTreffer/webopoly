<?php

echo $this->header;

?>


    <div id="main">
        <div class="row">
            <h1 class="col-xs-12">Logout erfolgreich</h1>
            <p class="col-xs-12">Sie sind jetzt abgemeldet. <a href="login">Klicken Sie hier um sich wieder anzumelden.</a></p>
        </div>
    </div>


<?php

echo $this->footer;

?>
