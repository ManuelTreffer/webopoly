<?php

require_once('includes/initialize.php');

$route = new Route();