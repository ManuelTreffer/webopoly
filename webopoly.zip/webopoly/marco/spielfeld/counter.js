var score = 0;

function countUp() {
    score += 1;
    document.getElementById("score").innerHTML = score;
};